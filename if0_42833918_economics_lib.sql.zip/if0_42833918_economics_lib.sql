-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: sql307.infinityfree.com
-- Generation Time: Sep 10, 2026 at 08:49 AM
-- Server version: 11.4.13-MariaDB
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `if0_42833918_economics_lib`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `mobile`, `username`, `password`, `created_at`) VALUES
(1, 'Annaji', 'Madavi', 'drannajimadavi@gmail.com', '09421319868', 'Adm', '$2y$10$L4FsY6SgUl3VLW6pdBB3CeXLp7exY00gMIQuT/wAFFH8XxPzQOqYK', '2026-09-08 12:27:35'),
(2, 'Sonalkumar', 'Nagarkar', 'drssnagarkar@gmail.com', '9657572981', 'drssnagarkar', '$2y$10$.npULbEJksp0XH7CiY07g.lxEfTnIdJuioEHnfz8bQgmPL3./pHVK', '2026-09-09 15:45:39'),
(3, 'Ravi', 'Kene', 'rvkene11@gmail.com', '9899963625', 'Rvkene', '$2y$10$kOg7vwKKq0UCN4FgsEv52u090hi3pLOA00/pUs3222nduoNcEsqSO', '2026-09-09 15:59:54'),
(4, 'Harshal', 'Dhuldhule', 'dhuldhuleharshal@gmail.com', '8668956772', 'har.shal6367', '$2y$10$HdaNbEPQG5m9i89gKH5Z5uXMt383ViGSk2JD87GQb5JoOLz2C3RHa', '2026-09-10 06:52:34'),
(5, 'Rohan', 'Raypure', 'rohanraypure105@gmail.com', '9370137819', 'rohan9512', '$2y$10$I6UcDgQRYLooWleLZ3RLxeamT6OpsjLGD7pJBGZH.LgOwks9kA4ie', '2026-09-10 10:07:18');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
